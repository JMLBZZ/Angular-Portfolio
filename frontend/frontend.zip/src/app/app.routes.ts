import { Routes } from '@angular/router';

import { authGuard } from './core/auth/auth.guard';
import { pendingChangesGuard } from './core/auth/pending-changes.guard';

import { PublicHomePageComponent } from './pages/public-home/public-home-page.component';
import { AdminLoginComponent } from './pages/admin-login/admin-login.component';
import { AdminLayoutComponent } from './layout/admin-layout/admin-layout.component';
import { AdminDashboardComponent } from './pages/admin-dashboard/admin-dashboard.component';
import { AdminProjectFormComponent } from './pages/admin-project-form/admin-project-form.component';
import { ProjectDetailPageComponent } from './pages/project-detail/project-detail-page.component';

export const routes: Routes = [
  {
    path: '',
    component: PublicHomePageComponent,
  },
  {
    path: 'admin/login',
    component: AdminLoginComponent,
  },
  {
    path: 'admin',
    component: AdminLayoutComponent,
    canActivate: [authGuard],
    children: [
      {
        path: 'dashboard',
        component: AdminDashboardComponent,
      },
      {
        path: 'projects/new',
        component: AdminProjectFormComponent,
        canDeactivate: [pendingChangesGuard],
      },
      {
        path: 'projects/:id/edit',
        component: AdminProjectFormComponent,
        canDeactivate: [pendingChangesGuard],
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'dashboard',
      },
    ],
  },
  {
    path: 'projects/:slug',
    component: ProjectDetailPageComponent,
  },
  {
    path: '**',
    redirectTo: '',
  },
];