import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { ProjectsApiService } from '../../core/api/projects-api.service';
import { SeoService } from '../../core/seo/seo.service';
import { Project } from '../../shared/models/project.model';
import { FallbackImageDirective } from '../../shared/directives/fallback-image.directive';
import { ProjectContentComponent } from '../../shared/components/project-content/project-content.component';

@Component({
  selector: 'app-project-detail-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    FallbackImageDirective,
    ProjectContentComponent,
  ],
  templateUrl: './project-detail-page.component.html',
})
export class ProjectDetailPageComponent implements OnInit {
  project: Project | null = null;
  isLoading = true;
  hasError = false;

  constructor(
    private route: ActivatedRoute,
    private projectsApi: ProjectsApiService,
    private seoService: SeoService
  ) {}

  ngOnInit(): void {
    const slug = this.route.snapshot.paramMap.get('slug');

    if (!slug) {
      this.project = null;
      this.hasError = true;
      this.isLoading = false;
      this.setErrorSeo();
      return;
    }

    this.projectsApi.getPublishedProjectBySlug(slug).subscribe({
      next: (project) => {
        this.project = project;
        this.isLoading = false;
        this.hasError = false;
        this.updateSeo(project);
      },
      error: () => {
        this.project = null;
        this.hasError = true;
        this.isLoading = false;
        this.setErrorSeo();
      },
    });
  }

  loc(value?: { fr?: string; en?: string } | null): string {
    if (!value) return '';
    return value.fr || value.en || '';
  }

  get heroImage(): string {
    const imagePath =
      this.project?.cover ||
      this.project?.image ||
      '/assets/projects/project-placeholder.svg';

    if (imagePath.startsWith('http://') || imagePath.startsWith('https://')) {
      return imagePath;
    }

    return `${window.location.origin}${imagePath.startsWith('/') ? imagePath : '/' + imagePath}`;
  }

  private updateSeo(project: Project): void {
    const description =
      this.loc(project.longDescription || project.description) ||
      project.title;

    this.seoService.updateSeo({
      title: `${project.title} — Projet | JMLBZZ`,
      description,
      image: this.heroImage,
      url: `${window.location.origin}/projects/${project.slug}`,
      type: 'article',
      robots: 'index, follow',
    });
  }

  private setErrorSeo(): void {
    this.seoService.updateSeo({
      title: 'Projet introuvable | JMLBZZ',
      description: 'La fiche projet demandée est introuvable.',
      image: `${window.location.origin}/assets/projects/project-placeholder.svg`,
      url: window.location.href,
      type: 'website',
      robots: 'noindex, follow',
    });
  }
}