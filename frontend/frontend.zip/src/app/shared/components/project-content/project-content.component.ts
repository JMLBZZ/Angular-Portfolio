import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

import { Project } from '../../../shared/models/project.model';
import { ActionButtonComponent } from '../action-button/action-button.component';

@Component({
  selector: 'app-project-content',
  standalone: true,
  imports: [
    CommonModule,
    TranslateModule,
    ActionButtonComponent,
  ],
  templateUrl: './project-content.component.html',
})
export class ProjectContentComponent {
  @Input({ required: true }) project!: Project;
  @Input() compact = false;

  loc(value?: { fr?: string; en?: string } | null): string {
    if (!value) return '';
    return value.fr || value.en || '';
  }
}